﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(storedatamining3.Startup))]
namespace storedatamining3
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
