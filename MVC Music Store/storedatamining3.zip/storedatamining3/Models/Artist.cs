﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace storedatamining3.Models
{
    public class Artist
    {
        public int ArtistId { get; set; }
        [DisplayName("Artist")]
        public string Name { get; set; }
        public List<Album> Albums { get; set; }
    }
}