﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using storedatamining3.Models;

namespace storedatamining3.Controllers
{
    public class StoreController : Controller
    {
        private MusicStoreData db = new MusicStoreData();

        // GET: Store
        public ActionResult Index()
        {
            var albums = db.Albums.Include(a => a.Artist).Include(a => a.Genre);
            return View(albums.ToList());
        }

        // GET: StoreManager/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Album album = db.Albums.Find(id);
            if (album == null)
            {
                return HttpNotFound();
            }
            return View(album);
        }

        public Genre FindGenreByName(string genreName)
        {
            return db.Genres
                .Include(p => p.Albums)
                .Where(p => p.Name == genreName)
                .SingleOrDefault();
        }

        public Artist FindArtistByName(string genreName)
        {
            return db.Artists
                .Include(p => p.Albums)
                .Where(p => p.Name == genreName)
                .SingleOrDefault();
        }

        public ActionResult Browse (string genre)
        {
           var example = FindGenreByName(genre);
            if (example == null)
            {
                throw new HttpException(404, "Wrong Url");
            }
            return View(example);
        }

        public ActionResult Browse2(string genre)
        {
            var example = FindArtistByName(genre);
            if (example == null)
            {
                throw new HttpException(404, "Wrong Url");
            }
            return View(example);
        }

        [ChildActionOnly]
        public ActionResult GenreMenu()
        {
            var genres = db.Genres.ToList();

            return PartialView(genres);
        }

        public ActionResult ArtistMenu()
        {
            var artists = db.Artists.ToList();

            return PartialView(artists);
        }


    }
}
